# ODZYSKIWANIE MAIN

Ten pakiet zachowuje stan `main` z commita:

    7a3a8848d31e02cd114d84e5048b242df7776223

## Pliki

Katalog `BrutalAntiFlowerGangForAI-main-7a3a884/` jest dokladna migawka `git archive` tego commita.

## Pelna historia

Plik `MAIN-HISTORY-7a3a884.bundle` zawiera wszystkie 42 commity osi `main`
oraz tagi `DLAAGENTA` i `v8.2.17`.

Przyklad odtworzenia historii bez zmiany istniejacego repo:

    mkdir odzyskane-main
    cd odzyskane-main
    git init
    git fetch ../MAIN-HISTORY-7a3a884.bundle refs/remotes/origin/main:refs/heads/main
    git fetch ../MAIN-HISTORY-7a3a884.bundle refs/tags/DLAAGENTA:refs/tags/DLAAGENTA
    git fetch ../MAIN-HISTORY-7a3a884.bundle refs/tags/v8.2.17:refs/tags/v8.2.17
    git switch main

Nie wykonuj force-push. Pusta plansza rekonstrukcji powinna byc zwyklym
nowym commitem, aby cala dotychczasowa historia pozostala osiagalna.
